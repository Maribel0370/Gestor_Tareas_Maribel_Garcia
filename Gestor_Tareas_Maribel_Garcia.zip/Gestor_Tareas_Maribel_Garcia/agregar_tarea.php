<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los valores del formulario
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $prioridad = $_POST['prioridad'];
    
    // Fecha y hora desde
    $fecha_desde = $_POST['fecha_desde'];
    $hora_desde = !empty($_POST['hora_desde']) ? $_POST['hora_desde'] : '00:00:00'; // Valor por defecto si no se ingresa hora
    
    // Fecha y hora hasta
    $fecha_hasta = $_POST['fecha_hasta'];
    $hora_hasta = !empty($_POST['hora_hasta']) ? $_POST['hora_hasta'] : '23:59:59'; // Valor por defecto si no se ingresa hora
    
    // Validar si la fecha está presente
    if (empty($fecha_desde) || empty($fecha_hasta)) {
        echo "Error: Las fechas son obligatorias.";
        exit();
    }

    // Preparar la consulta para insertar la tarea con las fechas y horas
    $sql = "INSERT INTO tareas (titulo, descripcion, prioridad, estado, fecha_desde, hora_desde, fecha_hasta, hora_hasta)
            VALUES ('$titulo', '$descripcion', '$prioridad', 'Pendiente', '$fecha_desde', '$hora_desde', '$fecha_hasta', '$hora_hasta')";

    // Ejecutar la consulta
    if ($conn->query($sql) === TRUE) {
        // Redirigir a la página principal si la tarea se agrega correctamente
        header("Location: index.php?success=tarea_agregada");
    } else {
        // Mostrar error en caso de que falle la consulta
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
