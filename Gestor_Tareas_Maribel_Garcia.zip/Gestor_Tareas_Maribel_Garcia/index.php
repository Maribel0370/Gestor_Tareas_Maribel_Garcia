<?php
session_start(); // Inicia la sesión

// Si el usuario desea cerrar sesión
if (isset($_GET['logout'])) {
    // Destruye la sesión y redirige al inicio
    session_destroy();
    header("Location: login.php"); // Redirige a la página de inicio de sesión
    exit();
}

// Incluir archivos necesarios para la conexión a la base de datos y funciones
include_once 'connection.php';
include_once 'funciones_tareas.php';

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Maribel" />
    <meta name="description" content="Mi primer gestor de tareas" />
    <meta name="keywords" content="Tareas, Tasks" />
    <title>Gestor de Tareas</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Estilos adicionales */
        .estado-select {
            width: 150px;
            padding: 5px;
            font-size: 16px;
            margin-right: 10px;
            margin-left: 15px;
            border-radius: 4px;
        }
        .form-group {
            margin-bottom: 1em;
        }
        .form-buttons {
            display: flex;
            gap: 10px;
        }

        /* Formulario oculto inicialmente */
        #formulario-main.hidden {
            display: none;
        }
    </style>
</head>
<body>
    <header>
        <h1 id="toggle-form">Gestor de Tareas</h1>
    </header>

    <!-- Formulario para agregar tareas -->
    <div id="formulario-main" class="hidden">
        <div id="formulario">
            <form action="agregar_tarea.php" method="POST">
                <div class="form-group">
                    <label for="titulo">Título:</label>
                    <input type="text" id="titulo" name="titulo" required>
                </div>

                <div class="form-group">
                    <label for="descripcion">Descripción:</label>
                    <input type="text" id="descripcion" name="descripcion">
                </div>

                <div class="form-group">
                    <label for="prioridad">Prioridad:</label>
                    <select id="prioridad" name="prioridad">
                        <option value="Urgente">Urgente</option>
                        <option value="Alta">Alta</option>
                        <option value="Media">Media</option>
                        <option value="Baja">Baja</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fecha_desde">Fecha desde:</label>
                    <input type="date" id="fecha_desde" name="fecha_desde" required>
                </div>

                <div class="form-group">
                    <label for="hora_desde">Hora desde:</label>
                    <input type="time" id="hora_desde" name="hora_desde">
                </div>

                <div class="form-group">
                    <label for="fecha_hasta">Fecha hasta:</label>
                    <input type="date" id="fecha_hasta" name="fecha_hasta" required>
                </div>

                <div class="form-group">
                    <label for="hora_hasta">Hora hasta:</label>
                    <input type="time" id="hora_hasta" name="hora_hasta">
                </div>

                <div class="form-buttons">
                    <button type="submit">Agregar tarea</button>
                    <button type="reset">Restablecer</button>
                </div>
            </form>
        </div>
    </div>

    <main id="tareas-main">
        <div id="tareas">
            <div class="columna" aria-labelledby="pendientes">
                <h2 id="pendientes" class="titulo-tarea">PENDIENTES</h2>
                <?php mostrarTareas('Pendiente'); ?>
            </div>
            <div class="columna" aria-labelledby="ejecucion">
                <h2 id="ejecucion" class="titulo-tarea">EJECUTANDO</h2>
                <?php mostrarTareas('Ejecución'); ?>
            </div>
            <div class="columna" aria-labelledby="finalizadas">
                <h2 id="finalizadas" class="titulo-tarea">FINALIZADAS</h2>
                <?php mostrarTareas('Finalizada'); ?>
            </div>
            <div class="columna" aria-labelledby="eliminadas">
                <h2 id="eliminadas" class="titulo-tarea">ELIMINADAS</h2>
                <?php mostrarTareas('Eliminada'); ?>
            </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const formulario = document.getElementById('formulario-main');
            const titulo = document.getElementById('toggle-form');

            // Revisar el estado guardado en sessionStorage
            const formVisible = sessionStorage.getItem('formVisible') === 'true';

            // Mostrar/ocultar el formulario basado en el valor guardado
            if (formVisible) {
                formulario.classList.remove('hidden');
            }

            // Alternar la visibilidad del formulario al hacer clic en el h1
            titulo.addEventListener('click', () => {
                formulario.classList.toggle('hidden');

                // Guardar el estado actual en sessionStorage
                const isFormVisible = !formulario.classList.contains('hidden');
                sessionStorage.setItem('formVisible', isFormVisible);
            });
        });
    </script>
</body>
</html>
