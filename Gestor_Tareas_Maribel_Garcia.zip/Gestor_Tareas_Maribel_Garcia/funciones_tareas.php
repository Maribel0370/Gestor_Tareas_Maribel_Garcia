<?php
include 'connection.php';

function mostrarTareas($estado) {
    global $conn;
    $sql = "SELECT * FROM tareas WHERE estado = '$estado' ORDER BY fecha_creacion DESC";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        echo "<div class='tarea'>";
        echo "<h3>" . htmlspecialchars($row['titulo']) . "</h3>";
        echo "<p>" . htmlspecialchars($row['descripcion']) . "</p>";

        // Mostrar la fecha desde y hora desde en una fila, seguido de fecha hasta y hora hasta
        echo "<p><strong>Fecha desde:</strong> " . $row['fecha_desde'] . " <strong>Hora desde:</strong> " . $row['hora_desde'] . "</p>";
        echo "<p><strong>Fecha hasta:</strong> " . $row['fecha_hasta'] . " <strong>Hora hasta:</strong> " . $row['hora_hasta'] . "</p>";

        // Prioridad
        echo "<span style='margin-right: 10px;'>Prioridad:</span> <span>" . htmlspecialchars($row['prioridad']) . "</span>";

        // Formulario para actualizar el estado de la tarea
        echo "<form action='actualizar_tarea.php' method='POST' style='display:inline;'>";
        echo "<label for='estado-select-" . $row['id'] . "' class='sr-only'>Cambiar estado</label>";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<select id='estado-select-" . $row['id'] . "' name='estado' class='estado-select'>"; // Añadimos la clase 'estado-select'
        
        // Opciones del estado
        $estados = ['Pendiente', 'Ejecución', 'Finalizada', 'Eliminada'];
        foreach ($estados as $est) {
            echo "<option value='$est' " . ($row['estado'] == $est ? 'selected' : '') . ">$est</option>";
        }
        echo "</select>";
        echo "<button type='submit' class='icon-btn update-btn' aria-label='Actualizar tarea'><i class='fas fa-pencil-alt'></i></button>"; // Botón para actualizar la tarea (ícono de lápiz)
        echo "</form>";

        // Botón para mover a Eliminadas solo en las columnas de Pendientes, Ejecución y Finalizadas
        if ($estado !== 'Eliminada') {
            echo "<form action='actualizar_tarea.php' method='POST' style='display:inline;'>";
            echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
            echo "<input type='hidden' name='estado' value='Eliminada'>"; // Mover a Eliminadas
            echo "<button type='submit' class='icon-btn delete-btn' aria-label='Mover a Eliminadas'><i class='fas fa-trash-alt'></i></button>"; // Botón para mover a Eliminadas (ícono de papelera)
            echo "</form>";
        }

        // Botón para eliminar definitivamente solo en la columna de Eliminadas
        if ($estado === 'Eliminada') {
            echo "<form action='eliminar_tarea.php' method='POST' style='display:inline;'>";
            echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";      
            echo "<button type='submit' class='icon-btn delete-btn' aria-label='Eliminar definitivamente'><i class='fas fa-trash-alt'></i></button>"; // Botón para eliminar definitivamente en la columna Eliminadas
            echo "</form>";
        }

        echo "</div>";
    }
}
?>
